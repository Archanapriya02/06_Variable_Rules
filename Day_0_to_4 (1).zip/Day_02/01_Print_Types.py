# print('hello python')
# print("hello python")

# print('hello worl'd') 
# print("hello pyt'hon")

# print('''Hello 
# World''')

# print('''Hello
#          World''')

# print('''Hello 

#         World''')

# print("""Hello

#          World""")

# print('''hello python''')
# print("""hello python""")

# print('hello py\'thon')
# print("hello py'thon")  
# print('''hello py'thon''')
# print("""hello py'thon""") 

# print('print(hello python)')
# print("print(hello python)")
# print('''print(hello python)''')
# print("""print(hello python)""")

# print('print(hello wor\'ld)')
# print("print(hello wor'ld)")
# print('''print(hello wor'ld)''')
# print("""print(hello wor'ld)""")

# print('hello'       'world') 
# print('hello'  ,    'world') 


# print("Python " * 5)
# print(3 * "Python ")

# print('4 ' *4)
# print('hello python3 '*2)

# print('python'*3.4)

# print('python'* 'core')