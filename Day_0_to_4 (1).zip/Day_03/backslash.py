# print('Hello Everyone Welcome to Python, \
# class which is running in 2nd floor at \
# josh innovations')

# print("we are learning python programming from,\
#  josh innovations in 2nd floor at 10:30AM")

# print('Taumatawhakatangihangakoauauotamateatur\
# ipukakapikimaungahoronukupokaiwhenuakiclstanatahu')
